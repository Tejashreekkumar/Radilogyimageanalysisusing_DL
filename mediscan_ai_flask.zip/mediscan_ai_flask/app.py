import os
import logging
from flask import Flask, send_from_directory, jsonify
from flask_jwt_extended import JWTManager
from flask_cors import CORS

from config import Config
from models import db, bcrypt
from routes.auth import auth_bp
from routes.predict import predict_bp
from routes.reports import reports_bp
from routes.chat import chat_bp

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(name)s: %(message)s'
)
logger = logging.getLogger(__name__)


def create_app(config_class=Config):
    app = Flask(__name__, static_folder='static', template_folder='templates')
    app.config.from_object(config_class)
    
    db.init_app(app)
    bcrypt.init_app(app)
    jwt = JWTManager(app)
    CORS(app, resources={r"/api/*": {"origins": "*"}})
    
    app.register_blueprint(auth_bp)
    app.register_blueprint(predict_bp)
    app.register_blueprint(reports_bp)
    app.register_blueprint(chat_bp)
    
    with app.app_context():
        os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
        os.makedirs(app.config['REPORT_FOLDER'], exist_ok=True)
        db.create_all()
        _seed_admin(app)
        
        from utils.model_loader import load_models
        load_models(app)
    
    @app.route('/', defaults={'path': ''})
    @app.route('/<path:path>')
    def serve_frontend(path):
        if path and path.startswith('api/'):
            return jsonify({'error': 'Not found'}), 404
        return send_from_directory('templates', 'index.html')
    
    @app.route('/static/uploads/<path:filename>')
    def serve_upload(filename):
        return send_from_directory(app.config['UPLOAD_FOLDER'], filename)
    
    @app.route('/static/reports/<path:filename>')
    def serve_report(filename):
        return send_from_directory(app.config['REPORT_FOLDER'], filename)
    
    @jwt.expired_token_loader
    def expired_token_callback(jwt_header, jwt_payload):
        return jsonify({'error': 'Token has expired'}), 401
    
    @jwt.invalid_token_loader
    def invalid_token_callback(error):
        return jsonify({'error': 'Invalid token'}), 401
    
    @jwt.unauthorized_loader
    def missing_token_callback(error):
        return jsonify({'error': 'Authorization token is required'}), 401
    
    return app


def _seed_admin(app):
    """Create default admin user if not exists."""
    from models import User
    if not User.query.filter_by(username='admin').first():
        admin = User(
            username='admin',
            email='admin@mediscan.ai',
            full_name='System Administrator',
            role='admin'
        )
        admin.set_password('Admin@123')
        db.session.add(admin)
        
        doctor = User(
            username='doctor',
            email='doctor@mediscan.ai',
            full_name='Dr. Jane Smith',
            role='doctor'
        )
        doctor.set_password('Doctor@123')
        db.session.add(doctor)
        
        db.session.commit()
        logger.info("Default users created: admin / Admin@123 | doctor / Doctor@123")


if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host='0.0.0.0', port=5000)
