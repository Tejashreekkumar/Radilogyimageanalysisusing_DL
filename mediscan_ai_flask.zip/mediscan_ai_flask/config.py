import os
from datetime import timedelta
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY', 'dev-jwt-secret-change-in-production')
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=24)
    
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL', 'sqlite:///radiology.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    UPLOAD_FOLDER = os.environ.get('UPLOAD_FOLDER', 'static/uploads')
    REPORT_FOLDER = os.environ.get('REPORT_FOLDER', 'static/reports')
    MAX_CONTENT_LENGTH = int(os.environ.get('MAX_CONTENT_LENGTH', 16 * 1024 * 1024))
    
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'bmp', 'tiff', 'webp'}
    
    OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY', '')
    
    MODEL_PATHS = {
        'brain': 'models/braintumorbest.pt',
        'kidney': 'models/kidneybest.pt',
        'bone': 'models/bone.pt'
    }
    
    SCAN_TYPE_MAP = {
        'MRI': 'brain',
        'CT': 'kidney',
        'X-ray': 'bone'
    }
    
    DISEASE_LABELS = {
        'brain': 'Brain Tumor',
        'kidney': 'Kidney Stone',
        'bone': 'Bone Fracture'
    }
