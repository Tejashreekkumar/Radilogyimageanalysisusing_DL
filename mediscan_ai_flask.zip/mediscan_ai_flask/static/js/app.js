/* ===== MediScan AI — Main Application JS ===== */

const API_BASE = '/api';
let authToken = localStorage.getItem('mediscan_token');
let currentUser = null;
let currentPrediction = null;
let diseaseChart = null;
let scanChart = null;
let currentPage = 1;
let chatContext = '';

/* ===== AUTH UTILITIES ===== */
function getHeaders(json = true) {
    const h = { 'Authorization': `Bearer ${authToken}` };
    if (json) h['Content-Type'] = 'application/json';
    return h;
}

async function apiCall(endpoint, options = {}) {
    const res = await fetch(`${API_BASE}${endpoint}`, {
        headers: getHeaders(options.body !== undefined && !(options.body instanceof FormData)),
        ...options
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    return data;
}

/* ===== AUTH SCREEN ===== */
function switchAuthTab(tab) {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    const idx = tab === 'login' ? 0 : 1;
    document.querySelectorAll('.auth-tab')[idx].classList.add('active');
    document.getElementById('login-form').classList.toggle('hidden', tab !== 'login');
    document.getElementById('register-form').classList.toggle('hidden', tab !== 'register');
}

async function handleLogin(e) {
    e.preventDefault();
    const btn = document.getElementById('login-btn');
    btn.disabled = true;
    btn.innerHTML = '<div class="spinner" style="width:18px;height:18px;margin:0"></div> Signing in...';
    setAuthError('login', '');
    try {
        const data = await fetch(`${API_BASE}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                username: document.getElementById('login-username').value,
                password: document.getElementById('login-password').value
            })
        }).then(async r => {
            const d = await r.json();
            if (!r.ok) throw new Error(d.error || 'Login failed');
            return d;
        });
        authToken = data.access_token;
        localStorage.setItem('mediscan_token', authToken);
        currentUser = data.user;
        enterApp();
    } catch (err) {
        setAuthError('login', err.message);
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<span>Sign In</span>';
    }
}

async function handleRegister(e) {
    e.preventDefault();
    const btn = document.getElementById('register-btn');
    btn.disabled = true;
    btn.innerHTML = '<div class="spinner" style="width:18px;height:18px;margin:0"></div> Creating...';
    setAuthError('register', '');
    try {
        await fetch(`${API_BASE}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                username: document.getElementById('reg-username').value,
                email: document.getElementById('reg-email').value,
                password: document.getElementById('reg-password').value,
                full_name: document.getElementById('reg-fullname').value,
                role: document.getElementById('reg-role').value
            })
        }).then(async r => {
            const d = await r.json();
            if (!r.ok) throw new Error(d.error || 'Registration failed');
            return d;
        });
        showToast('Account created! Please sign in.', 'success');
        switchAuthTab('login');
    } catch (err) {
        setAuthError('register', err.message);
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<span>Create Account</span>';
    }
}

function setAuthError(form, msg) {
    const el = document.getElementById(`${form}-error`);
    if (msg) { el.textContent = msg; el.classList.remove('hidden'); }
    else el.classList.add('hidden');
}

function logout() {
    localStorage.removeItem('mediscan_token');
    authToken = null;
    currentUser = null;
    currentPrediction = null;
    document.getElementById('auth-screen').classList.add('active');
    document.getElementById('auth-screen').classList.remove('hidden');
    document.getElementById('app-screen').classList.add('hidden');
    document.getElementById('app-screen').classList.remove('active');
}

/* ===== APP INIT ===== */
async function init() {
    if (authToken) {
        try {
            const data = await apiCall('/auth/me');
            currentUser = data.user;
            enterApp();
        } catch {
            localStorage.removeItem('mediscan_token');
            authToken = null;
        }
    }
}

function enterApp() {
    document.getElementById('auth-screen').classList.remove('active');
    document.getElementById('auth-screen').classList.add('hidden');
    document.getElementById('app-screen').classList.remove('hidden');
    document.getElementById('app-screen').classList.add('active');
    updateUserUI();
    navigateTo('dashboard');
}

function updateUserUI() {
    if (!currentUser) return;
    const name = currentUser.full_name || currentUser.username;
    document.getElementById('user-avatar').textContent = name.charAt(0).toUpperCase();
    document.getElementById('sidebar-user-name').textContent = name;
    document.getElementById('sidebar-user-role').textContent = currentUser.role;
    document.getElementById('topbar-user').textContent = name;
}

/* ===== NAVIGATION ===== */
function navigateTo(page) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    
    const pageEl = document.getElementById(`page-${page}`);
    if (pageEl) pageEl.classList.add('active');
    
    const navBtn = document.querySelector(`[data-page="${page}"]`);
    if (navBtn) navBtn.classList.add('active');
    
    const titles = {
        'dashboard': 'Dashboard',
        'upload': 'Upload & Predict',
        'history': 'Scan History',
        'reports': 'PDF Reports',
        'disease-info': 'Disease Information'
    };
    document.getElementById('page-title').textContent = titles[page] || page;
    
    if (page === 'dashboard') loadDashboard();
    else if (page === 'history') loadHistory(1);
    else if (page === 'reports') loadReports();
    
    if (window.innerWidth <= 900) {
        document.getElementById('sidebar').classList.remove('open');
        document.getElementById('sidebar-overlay').classList.remove('open');
    }
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    sidebar.classList.toggle('open');
    overlay.classList.toggle('open');
}

/* ===== DASHBOARD ===== */
async function loadDashboard() {
    try {
        const data = await apiCall('/predict/stats');
        
        document.getElementById('total-scans').textContent = data.total_scans;
        document.getElementById('brain-count').textContent = data.disease_distribution['Brain Tumor'] || 0;
        document.getElementById('kidney-count').textContent = data.disease_distribution['Kidney Stone'] || 0;
        document.getElementById('bone-count').textContent = data.disease_distribution['Bone Fracture'] || 0;
        
        renderDiseaseChart(data.disease_distribution);
        renderScanChart(data.scan_type_distribution);
        renderRecentTable(data.recent_predictions);
    } catch (err) {
        showToast('Failed to load dashboard: ' + err.message, 'error');
    }
}

function renderDiseaseChart(distribution) {
    const ctx = document.getElementById('diseaseChart').getContext('2d');
    if (diseaseChart) diseaseChart.destroy();
    const labels = Object.keys(distribution);
    const values = Object.values(distribution);
    if (labels.length === 0) { labels.push('No data'); values.push(0); }
    diseaseChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels,
            datasets: [{
                data: values,
                backgroundColor: ['#ec4899', '#22c55e', '#f59e0b', '#3b82f6'],
                borderWidth: 0, hoverOffset: 8
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { position: 'bottom', labels: { padding: 12, font: { size: 11 } } } }
        }
    });
}

function renderScanChart(distribution) {
    const ctx = document.getElementById('scanChart').getContext('2d');
    if (scanChart) scanChart.destroy();
    const labels = Object.keys(distribution);
    const values = Object.values(distribution);
    if (labels.length === 0) { labels.push('No data'); values.push(0); }
    scanChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels,
            datasets: [{
                label: 'Scans',
                data: values,
                backgroundColor: ['#3b82f6', '#8b5cf6', '#f59e0b'],
                borderRadius: 6, borderSkipped: false
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                y: { beginAtZero: true, ticks: { stepSize: 1 }, grid: { color: '#f1f5f9' } },
                x: { grid: { display: false } }
            }
        }
    });
}

function renderRecentTable(predictions) {
    const tbody = document.getElementById('recent-predictions-body');
    if (!predictions || predictions.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-row">No scans yet. Upload an image to get started.</td></tr>';
        return;
    }
    tbody.innerHTML = predictions.map(p => `
        <tr>
            <td><strong>#${p.id}</strong></td>
            <td>${p.patient_name || '—'}</td>
            <td><span class="badge badge-blue">${p.scan_type}</span></td>
            <td>${p.disease_type || '—'}</td>
            <td>${p.disease_detected ? `<span style="font-weight:600;color:#ef4444">${p.disease_detected}</span>` : '—'}</td>
            <td>${confidenceCell(p.confidence)}</td>
            <td>${formatDate(p.created_at)}</td>
            <td>
                <button class="btn btn-outline" style="padding:5px 10px;font-size:0.78rem" onclick="viewPrediction(${p.id})">View</button>
            </td>
        </tr>
    `).join('');
}

/* ===== UPLOAD & PREDICT ===== */
let selectedFile = null;

function handleFileSelect(e) {
    const file = e.target.files[0];
    if (!file) return;
    selectedFile = file;
    
    const reader = new FileReader();
    reader.onload = (ev) => {
        document.getElementById('image-preview').src = ev.target.result;
        document.getElementById('image-preview-container').classList.remove('hidden');
        document.getElementById('dropzone').classList.add('hidden');
    };
    reader.readAsDataURL(file);
}

function removeImage() {
    selectedFile = null;
    document.getElementById('image-input').value = '';
    document.getElementById('image-preview-container').classList.add('hidden');
    document.getElementById('dropzone').classList.remove('hidden');
}

const dropzone = document.getElementById('dropzone');
if (dropzone) {
    dropzone.addEventListener('dragover', e => { e.preventDefault(); dropzone.style.borderColor = '#3b82f6'; });
    dropzone.addEventListener('dragleave', () => { dropzone.style.borderColor = ''; });
    dropzone.addEventListener('drop', e => {
        e.preventDefault();
        dropzone.style.borderColor = '';
        const file = e.dataTransfer.files[0];
        if (file) {
            selectedFile = file;
            const reader = new FileReader();
            reader.onload = (ev) => {
                document.getElementById('image-preview').src = ev.target.result;
                document.getElementById('image-preview-container').classList.remove('hidden');
                document.getElementById('dropzone').classList.add('hidden');
            };
            reader.readAsDataURL(file);
        }
    });
}

async function handleUpload(e) {
    e.preventDefault();
    if (!selectedFile) { showToast('Please select an image file.', 'error'); return; }
    
    const scanType = document.getElementById('scan-type').value;
    if (!scanType) { showToast('Please select a scan type.', 'error'); return; }
    
    showLoader('Running AI diagnosis...');
    const btn = document.getElementById('upload-btn');
    btn.disabled = true;
    
    try {
        const formData = new FormData();
        formData.append('image', selectedFile);
        formData.append('scan_type', scanType);
        formData.append('patient_name', document.getElementById('patient-name').value);
        formData.append('notes', document.getElementById('pred-notes').value);
        
        const res = await fetch(`${API_BASE}/predict/upload`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${authToken}` },
            body: formData
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Prediction failed');
        
        currentPrediction = data.prediction;
        chatContext = `${data.prediction.disease_detected} detected with ${data.prediction.confidence}% confidence via ${data.prediction.scan_type}`;
        
        showPredictionResult(data.prediction);
        showToast('Diagnosis complete!', 'success');
    } catch (err) {
        showToast('Prediction failed: ' + err.message, 'error');
    } finally {
        hideLoader();
        btn.disabled = false;
    }
}

function showPredictionResult(p) {
    document.getElementById('result-panel').classList.remove('hidden');
    document.getElementById('result-disease').textContent = p.disease_detected || 'No abnormality';
    document.getElementById('result-confidence').textContent = `Confidence: ${p.confidence}%`;
    
    const base = '/static/uploads/';
    document.getElementById('result-original').src = p.original_image ? base + p.original_image : '';
    document.getElementById('result-annotated').src = p.annotated_image ? base + p.annotated_image : '';
    document.getElementById('result-heatmap').src = p.heatmap_image ? base + p.heatmap_image : '';
    document.getElementById('report-status').classList.add('hidden');
}

async function generateReport() {
    if (!currentPrediction) { showToast('No prediction available.', 'error'); return; }
    showLoader('Generating PDF report...');
    try {
        const data = await apiCall(`/reports/generate/${currentPrediction.id}`, { method: 'POST' });
        const statusEl = document.getElementById('report-status');
        statusEl.innerHTML = `Report ready! <a href="/api/reports/download/${data.report.id}" target="_blank" style="color:#1d4ed8;font-weight:600">Download PDF</a>`;
        statusEl.className = 'report-status report-success';
        statusEl.classList.remove('hidden');
        showToast('PDF report generated!', 'success');
    } catch (err) {
        showToast('Failed to generate report: ' + err.message, 'error');
    } finally {
        hideLoader();
    }
}

function askChatbotAboutResult() {
    if (!currentPrediction) return;
    const msg = `Explain my result: ${currentPrediction.disease_detected} detected with ${currentPrediction.confidence}% confidence`;
    toggleChat(true);
    sendMessageWithContext(msg, chatContext);
}

/* ===== HISTORY ===== */
async function loadHistory(page = 1) {
    currentPage = page;
    const tbody = document.getElementById('history-body');
    tbody.innerHTML = '<tr><td colspan="8" class="empty-row">Loading...</td></tr>';
    try {
        const data = await apiCall(`/predict/history?page=${page}&per_page=10`);
        if (!data.predictions.length) {
            tbody.innerHTML = '<tr><td colspan="8" class="empty-row">No scans yet.</td></tr>';
            document.getElementById('history-pagination').innerHTML = '';
            return;
        }
        tbody.innerHTML = data.predictions.map(p => `
            <tr>
                <td><strong>#${p.id}</strong></td>
                <td>${p.patient_name || '—'}</td>
                <td><span class="badge badge-blue">${p.scan_type}</span></td>
                <td>${p.disease_type || '—'}</td>
                <td>${p.disease_detected || '—'}</td>
                <td>${confidenceCell(p.confidence)}</td>
                <td>${formatDate(p.created_at)}</td>
                <td style="display:flex;gap:6px">
                    <button class="btn btn-outline" style="padding:5px 10px;font-size:0.78rem" onclick="viewPrediction(${p.id})">View</button>
                    <button class="btn btn-outline" style="padding:5px 10px;font-size:0.78rem" onclick="generateReportById(${p.id})">PDF</button>
                </td>
            </tr>
        `).join('');
        renderPagination(data.pages, page);
    } catch (err) {
        tbody.innerHTML = `<tr><td colspan="8" class="empty-row">Error: ${err.message}</td></tr>`;
    }
}

function renderPagination(total, current) {
    const container = document.getElementById('history-pagination');
    if (total <= 1) { container.innerHTML = ''; return; }
    let html = '';
    for (let i = 1; i <= total; i++) {
        html += `<button class="${i === current ? 'active' : ''}" onclick="loadHistory(${i})">${i}</button>`;
    }
    container.innerHTML = html;
}

async function generateReportById(predId) {
    showLoader('Generating report...');
    try {
        const data = await apiCall(`/reports/generate/${predId}`, { method: 'POST' });
        showToast('Report ready!', 'success');
        window.open(`/api/reports/download/${data.report.id}`, '_blank');
    } catch (err) {
        showToast('Report failed: ' + err.message, 'error');
    } finally {
        hideLoader();
    }
}

/* ===== REPORTS ===== */
async function loadReports() {
    const tbody = document.getElementById('reports-body');
    tbody.innerHTML = '<tr><td colspan="4" class="empty-row">Loading...</td></tr>';
    try {
        const data = await apiCall('/reports/');
        if (!data.reports.length) {
            tbody.innerHTML = '<tr><td colspan="4" class="empty-row">No reports generated yet.</td></tr>';
            return;
        }
        tbody.innerHTML = data.reports.map(r => `
            <tr>
                <td><strong>RPT-${String(r.id).padStart(5, '0')}</strong></td>
                <td>#${r.prediction_id}</td>
                <td>${formatDate(r.created_at)}</td>
                <td>
                    <a href="/api/reports/download/${r.id}" target="_blank" class="btn btn-outline" style="padding:5px 12px;font-size:0.78rem">
                        Download PDF
                    </a>
                </td>
            </tr>
        `).join('');
    } catch (err) {
        tbody.innerHTML = `<tr><td colspan="4" class="empty-row">Error: ${err.message}</td></tr>`;
    }
}

/* ===== VIEW PREDICTION MODAL ===== */
async function viewPrediction(id) {
    try {
        const data = await apiCall(`/predict/${id}`);
        const p = data.prediction;
        const modal = document.getElementById('pred-modal');
        document.getElementById('modal-title').textContent = `Prediction #${p.id} Details`;
        
        const base = '/static/uploads/';
        document.getElementById('modal-content').innerHTML = `
            <div class="modal-content-grid">
                <div class="modal-field"><div class="modal-field-label">Patient</div><div class="modal-field-value">${p.patient_name || '—'}</div></div>
                <div class="modal-field"><div class="modal-field-label">Scan Type</div><div class="modal-field-value">${p.scan_type}</div></div>
                <div class="modal-field"><div class="modal-field-label">Disease Type</div><div class="modal-field-value">${p.disease_type || '—'}</div></div>
                <div class="modal-field"><div class="modal-field-label">Finding</div><div class="modal-field-value" style="color:#ef4444;font-weight:700">${p.disease_detected || '—'}</div></div>
                <div class="modal-field"><div class="modal-field-label">Confidence</div><div class="modal-field-value">${p.confidence ? p.confidence + '%' : '—'}</div></div>
                <div class="modal-field"><div class="modal-field-label">Date</div><div class="modal-field-value">${formatDate(p.created_at)}</div></div>
                ${p.notes ? `<div class="modal-field" style="grid-column:1/-1"><div class="modal-field-label">Notes</div><div class="modal-field-value">${p.notes}</div></div>` : ''}
            </div>
            <div class="modal-images" style="margin-top:16px">
                ${p.original_image ? `<div><p class="image-label">Original</p><img src="${base + p.original_image}" /></div>` : ''}
                ${p.annotated_image ? `<div><p class="image-label">Annotated</p><img src="${base + p.annotated_image}" /></div>` : ''}
                ${p.heatmap_image ? `<div><p class="image-label">Grad-CAM</p><img src="${base + p.heatmap_image}" /></div>` : ''}
            </div>
            <div style="margin-top:16px;display:flex;gap:10px;flex-wrap:wrap">
                <button class="btn btn-primary" onclick="generateReportById(${p.id})">Generate PDF Report</button>
                <button class="btn btn-outline" onclick="document.getElementById('pred-modal').classList.add('hidden')">Close</button>
            </div>
        `;
        modal.classList.remove('hidden');
    } catch (err) {
        showToast('Failed to load prediction: ' + err.message, 'error');
    }
}

function closeModal(e) {
    if (e.target.id === 'pred-modal') {
        document.getElementById('pred-modal').classList.add('hidden');
    }
}

/* ===== CHATBOT ===== */
function toggleChat(forceOpen) {
    const panel = document.getElementById('chat-panel');
    if (forceOpen) {
        panel.classList.remove('hidden');
    } else {
        panel.classList.toggle('hidden');
    }
    if (!panel.classList.contains('hidden')) {
        setTimeout(() => document.getElementById('chat-input').focus(), 100);
    }
}

function handleChatKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendChatMessage();
    }
}

function sendQuickMessage(msg) {
    sendMessageWithContext(msg, chatContext);
}

async function sendChatMessage() {
    const input = document.getElementById('chat-input');
    const msg = input.value.trim();
    if (!msg) return;
    input.value = '';
    sendMessageWithContext(msg, chatContext);
}

async function sendMessageWithContext(msg, context) {
    appendChatMessage(msg, 'user');
    const typingEl = showTypingIndicator();
    
    try {
        const data = await apiCall('/chat/', {
            method: 'POST',
            body: JSON.stringify({ message: msg, prediction_context: context })
        });
        typingEl.remove();
        appendChatMessage(data.response, 'bot');
    } catch (err) {
        typingEl.remove();
        appendChatMessage('Sorry, I encountered an error. Please try again.', 'bot');
    }
}

function appendChatMessage(text, role) {
    const container = document.getElementById('chat-messages');
    const div = document.createElement('div');
    div.className = `chat-message ${role}`;
    div.innerHTML = `<div class="chat-bubble">${escapeHtml(text)}</div>`;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
}

function showTypingIndicator() {
    const container = document.getElementById('chat-messages');
    const div = document.createElement('div');
    div.className = 'chat-message bot';
    div.innerHTML = `<div class="chat-bubble"><div class="typing-indicator"><div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div></div></div>`;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
    return div;
}

/* ===== UTILS ===== */
function showLoader(text = 'Processing...') {
    document.getElementById('loader-text').textContent = text;
    document.getElementById('loader-overlay').classList.remove('hidden');
}
function hideLoader() {
    document.getElementById('loader-overlay').classList.add('hidden');
}

function showToast(msg, type = 'info') {
    const toast = document.getElementById('toast');
    toast.textContent = msg;
    toast.className = `toast ${type}`;
    setTimeout(() => toast.classList.add('hidden'), 3500);
}

function formatDate(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' ' +
        d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

function confidenceCell(conf) {
    if (conf == null) return '—';
    const pct = Math.min(100, Math.max(0, conf));
    const color = pct >= 80 ? '#ef4444' : pct >= 60 ? '#f59e0b' : '#22c55e';
    return `<div style="font-weight:600;color:${color}">${pct}%</div>
            <div class="confidence-bar"><div class="confidence-fill" style="width:${pct}%;background:${color}"></div></div>`;
}

function escapeHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/\n/g, '<br>');
}

/* ===== BOOT ===== */
document.addEventListener('DOMContentLoaded', init);
