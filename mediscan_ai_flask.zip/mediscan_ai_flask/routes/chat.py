import os
import logging
from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity

logger = logging.getLogger(__name__)

chat_bp = Blueprint('chat', __name__, url_prefix='/api/chat')

DISEASE_KNOWLEDGE = {
    'brain tumor': {
        'description': (
            "A brain tumor is a mass of abnormal cells in the brain. "
            "It can be benign (non-cancerous) or malignant (cancerous). "
            "Types include glioma, meningioma, and pituitary adenoma."
        ),
        'symptoms': [
            "Persistent headaches (often worse in the morning)",
            "Seizures or convulsions",
            "Vision, hearing, or speech problems",
            "Difficulty with balance and coordination",
            "Memory loss or personality changes",
            "Nausea and vomiting"
        ],
        'precautions': [
            "Follow prescribed medications strictly",
            "Avoid strenuous physical activities without doctor clearance",
            "Regular follow-up MRI scans as advised",
            "Join a support group for emotional health",
            "Maintain a healthy diet and sleep schedule"
        ],
        'treatment': [
            "Surgery (craniotomy) to remove the tumor",
            "Radiation therapy to kill remaining cancer cells",
            "Chemotherapy (e.g., Temozolomide for glioblastoma)",
            "Targeted therapy and immunotherapy for eligible cases",
            "Steroid medications to reduce swelling"
        ],
        'specialist': 'neurosurgeon or neuro-oncologist'
    },
    'kidney stone': {
        'description': (
            "Kidney stones are hard mineral and salt deposits that form inside the kidneys. "
            "They can form when urine becomes concentrated, allowing minerals to crystallize. "
            "Common types include calcium oxalate, uric acid, and struvite stones."
        ),
        'symptoms': [
            "Severe, sharp pain in the back, side, lower abdomen, or groin",
            "Pain or burning during urination",
            "Pink, red, or brown urine (hematuria)",
            "Cloudy or foul-smelling urine",
            "Persistent urge to urinate",
            "Nausea and vomiting",
            "Fever and chills (if infection is present)"
        ],
        'precautions': [
            "Drink plenty of water (2.5–3 liters per day)",
            "Reduce salt and animal protein intake",
            "Limit oxalate-rich foods (spinach, nuts, beets)",
            "Maintain a healthy body weight",
            "Follow up with urology as scheduled"
        ],
        'treatment': [
            "Small stones: Pain relief medications, increased fluid intake",
            "Shock Wave Lithotripsy (ESWL) for medium stones",
            "Ureteroscopy with laser fragmentation",
            "Percutaneous Nephrolithotomy (PCNL) for large stones",
            "Medical therapy with alpha-blockers to facilitate stone passage"
        ],
        'specialist': 'urologist'
    },
    'bone fracture': {
        'description': (
            "A bone fracture is a break in the continuity of the bone. "
            "It can range from a hairline crack to a complete break. "
            "Types include simple, compound, comminuted, greenstick, and stress fractures."
        ),
        'symptoms': [
            "Sudden, severe pain at the injury site",
            "Swelling, bruising, or tenderness",
            "Visible deformity or unnatural angle",
            "Inability to move or bear weight on the affected area",
            "Numbness or tingling (if nerves are affected)",
            "Bone protruding through skin (open fracture)"
        ],
        'precautions': [
            "Immobilize the affected area — do not attempt to realign the bone",
            "Avoid putting weight on the fractured area",
            "Follow the prescribed rehabilitation program",
            "Take prescribed calcium and vitamin D supplements",
            "Attend all follow-up X-ray appointments"
        ],
        'treatment': [
            "Cast or splinting for stable fractures",
            "Traction for alignment of complex fractures",
            "Surgical fixation using pins, plates, rods, or screws (ORIF)",
            "External fixation for complex open fractures",
            "Physical therapy for rehabilitation and strength building"
        ],
        'specialist': 'orthopedic surgeon'
    }
}


def _get_openai_response(message, context, api_key):
    """Get response from OpenAI API."""
    from openai import OpenAI
    
    client = OpenAI(api_key=api_key)
    
    system_prompt = (
        "You are MediScan AI, an intelligent medical assistant specialized in radiology and diagnostics. "
        "You provide helpful, accurate, and empathetic information about diseases detected through medical imaging. "
        "You always recommend consulting a licensed physician for definitive diagnosis and treatment. "
        "Keep responses concise, clear, and helpful. Do not provide specific dosage or prescription advice."
    )
    
    messages = [{"role": "system", "content": system_prompt}]
    
    if context:
        messages.append({
            "role": "system",
            "content": f"Current scan context: {context}. Tailor your response accordingly."
        })
    
    messages.append({"role": "user", "content": message})
    
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=messages,
        max_tokens=500,
        temperature=0.7
    )
    
    return response.choices[0].message.content


def _get_rule_based_response(message, context):
    """Rule-based chatbot response when OpenAI is not available."""
    message_lower = message.lower()
    
    if context:
        context_lower = context.lower()
        for disease_key in DISEASE_KNOWLEDGE:
            if disease_key in context_lower:
                info = DISEASE_KNOWLEDGE[disease_key]
                confidence_note = ""
                
                for part in context.split():
                    if '%' in part:
                        confidence_note = f" with {part} confidence"
                        break
                
                if any(w in message_lower for w in ['what is', 'explain', 'tell me', 'describe', 'about']):
                    return (
                        f"Based on your scan, {disease_key.title()} was detected{confidence_note}.\n\n"
                        f"{info['description']}\n\n"
                        f"I strongly recommend consulting a {info['specialist']} for proper evaluation."
                    )
                elif any(w in message_lower for w in ['symptom', 'sign', 'feel']):
                    symptoms = '\n• '.join(info['symptoms'])
                    return f"Common symptoms of {disease_key.title()}:\n• {symptoms}\n\nPlease consult a {info['specialist']} immediately."
                elif any(w in message_lower for w in ['precaution', 'prevent', 'avoid', 'careful']):
                    precautions = '\n• '.join(info['precautions'])
                    return f"Precautions for {disease_key.title()}:\n• {precautions}"
                elif any(w in message_lower for w in ['treatment', 'cure', 'treat', 'remedy', 'medicine', 'medication']):
                    treatments = '\n• '.join(info['treatment'])
                    return f"Treatment options for {disease_key.title()}:\n• {treatments}\n\nConsult a {info['specialist']} to determine the best plan for you."
    
    for disease_key, info in DISEASE_KNOWLEDGE.items():
        if disease_key in message_lower or disease_key.split()[0] in message_lower:
            if any(w in message_lower for w in ['what is', 'explain', 'tell me', 'describe', 'about']):
                return f"{disease_key.title()}:\n\n{info['description']}"
            elif any(w in message_lower for w in ['symptom', 'sign']):
                symptoms = '\n• '.join(info['symptoms'])
                return f"Symptoms of {disease_key.title()}:\n• {symptoms}"
            elif any(w in message_lower for w in ['precaution', 'prevent']):
                precautions = '\n• '.join(info['precautions'])
                return f"Precautions for {disease_key.title()}:\n• {precautions}"
            elif any(w in message_lower for w in ['treatment', 'cure', 'treat']):
                treatments = '\n• '.join(info['treatment'])
                return f"Treatments for {disease_key.title()}:\n• {treatments}"
            else:
                return (
                    f"About {disease_key.title()}:\n{info['description']}\n\n"
                    f"Would you like to know about symptoms, precautions, or treatment options?"
                )
    
    greetings = ['hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening']
    if any(g in message_lower for g in greetings):
        return (
            "Hello! I'm MediScan AI, your intelligent radiology assistant. "
            "I can help you understand your scan results, explain diseases, symptoms, precautions, and treatment options. "
            "How can I assist you today?"
        )
    
    if any(w in message_lower for w in ['help', 'what can you do', 'capabilities']):
        return (
            "I can help you with:\n"
            "• Understanding scan results (Brain Tumor, Kidney Stone, Bone Fracture)\n"
            "• Explaining disease symptoms and causes\n"
            "• Providing precautions and lifestyle advice\n"
            "• Overview of treatment options\n"
            "• General medical guidance\n\n"
            "Just ask me anything about your diagnosis or these conditions!"
        )
    
    return (
        "I'm here to help you understand medical imaging results and related health information. "
        "You can ask me about brain tumors, kidney stones, bone fractures — their symptoms, precautions, and treatments. "
        "For accurate medical advice, please always consult a qualified physician."
    )


@chat_bp.route('/', methods=['POST'])
@jwt_required()
def chat():
    data = request.get_json()
    
    if not data or not data.get('message'):
        return jsonify({'error': 'Message is required'}), 400
    
    message = data['message'].strip()
    prediction_context = data.get('prediction_context', '')
    
    api_key = current_app.config.get('OPENAI_API_KEY', '')
    
    if api_key and api_key != 'your-openai-api-key-optional':
        try:
            response_text = _get_openai_response(message, prediction_context, api_key)
            source = 'openai'
        except Exception as e:
            logger.warning(f"OpenAI failed, falling back to rule-based: {e}")
            response_text = _get_rule_based_response(message, prediction_context)
            source = 'rule-based'
    else:
        response_text = _get_rule_based_response(message, prediction_context)
        source = 'rule-based'
    
    return jsonify({
        'response': response_text,
        'source': source
    }), 200
