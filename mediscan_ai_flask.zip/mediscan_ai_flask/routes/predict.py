import os
import uuid
import logging
from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity
from werkzeug.utils import secure_filename
from models import db, User, Prediction
from utils.predictor import run_prediction
from utils.gradcam import generate_gradcam_heatmap
from utils.model_loader import get_model, is_model_available

logger = logging.getLogger(__name__)

predict_bp = Blueprint('predict', __name__, url_prefix='/api/predict')

SCAN_TO_MODEL = {
    'MRI': 'brain',
    'CT': 'kidney',
    'X-ray': 'bone'
}

DISEASE_TYPE_MAP = {
    'brain': 'Brain Tumor',
    'kidney': 'Kidney Stone',
    'bone': 'Bone Fracture'
}


def allowed_file(filename):
    allowed = current_app.config.get('ALLOWED_EXTENSIONS', {'png', 'jpg', 'jpeg'})
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed


@predict_bp.route('/upload', methods=['POST'])
@jwt_required()
def upload_and_predict():
    user_id = int(get_jwt_identity())
    
    if 'image' not in request.files:
        return jsonify({'error': 'No image file provided'}), 400
    
    file = request.files['image']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'error': 'File type not allowed. Use PNG, JPG, JPEG, etc.'}), 400
    
    scan_type = request.form.get('scan_type', 'X-ray')
    patient_name = request.form.get('patient_name', '')
    notes = request.form.get('notes', '')
    
    if scan_type not in SCAN_TO_MODEL:
        return jsonify({'error': f'Invalid scan type. Choose from: {list(SCAN_TO_MODEL.keys())}'}), 400
    
    model_key = SCAN_TO_MODEL[scan_type]
    
    upload_folder = current_app.config['UPLOAD_FOLDER']
    os.makedirs(upload_folder, exist_ok=True)
    
    ext = secure_filename(file.filename).rsplit('.', 1)[-1].lower()
    orig_filename = f"original_{uuid.uuid4().hex}.{ext}"
    orig_path = os.path.join(upload_folder, orig_filename)
    file.save(orig_path)
    
    model = get_model(model_key)
    model_available = is_model_available(model_key)
    
    result = run_prediction(orig_path, model_key, upload_folder, model, model_available)
    
    heatmap_filename = generate_gradcam_heatmap(orig_path, upload_folder)
    
    prediction = Prediction(
        user_id=user_id,
        scan_type=scan_type,
        disease_type=DISEASE_TYPE_MAP.get(model_key),
        disease_detected=result['disease_detected'],
        confidence=result['confidence'],
        original_image=orig_filename,
        annotated_image=result.get('annotated_image'),
        heatmap_image=heatmap_filename,
        patient_name=patient_name or None,
        notes=notes or None
    )
    db.session.add(prediction)
    db.session.commit()
    
    return jsonify({
        'message': 'Prediction complete',
        'prediction': prediction.to_dict(),
        'model_mode': 'real' if model_available else 'demo'
    }), 201


@predict_bp.route('/history', methods=['GET'])
@jwt_required()
def get_history():
    user_id = int(get_jwt_identity())
    current_user = User.query.get_or_404(user_id)
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    if current_user.role == 'admin':
        pq = Prediction.query
    else:
        pq = Prediction.query.filter_by(user_id=user_id)
    
    paginated = pq.order_by(Prediction.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return jsonify({
        'predictions': [p.to_dict() for p in paginated.items],
        'total': paginated.total,
        'pages': paginated.pages,
        'current_page': paginated.page
    }), 200


@predict_bp.route('/<int:prediction_id>', methods=['GET'])
@jwt_required()
def get_prediction(prediction_id):
    user_id = int(get_jwt_identity())
    current_user = User.query.get_or_404(user_id)
    
    pred = Prediction.query.get_or_404(prediction_id)
    
    if pred.user_id != user_id and current_user.role != 'admin':
        return jsonify({'error': 'Forbidden'}), 403
    
    return jsonify({'prediction': pred.to_dict()}), 200


@predict_bp.route('/stats', methods=['GET'])
@jwt_required()
def get_stats():
    user_id = int(get_jwt_identity())
    current_user = User.query.get_or_404(user_id)
    
    if current_user.role == 'admin':
        pq = Prediction.query
    else:
        pq = Prediction.query.filter_by(user_id=user_id)
    
    total = pq.count()
    
    disease_counts = {}
    scan_counts = {}
    for p in pq.all():
        dt = p.disease_type or 'Unknown'
        disease_counts[dt] = disease_counts.get(dt, 0) + 1
        st = p.scan_type or 'Unknown'
        scan_counts[st] = scan_counts.get(st, 0) + 1
    
    recent = pq.order_by(Prediction.created_at.desc()).limit(5).all()
    
    return jsonify({
        'total_scans': total,
        'disease_distribution': disease_counts,
        'scan_type_distribution': scan_counts,
        'recent_predictions': [p.to_dict() for p in recent]
    }), 200
