import os
import logging
from flask import Blueprint, jsonify, send_from_directory, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import db, User, Prediction, Report
from utils.pdf_report import generate_pdf_report

logger = logging.getLogger(__name__)

reports_bp = Blueprint('reports', __name__, url_prefix='/api/reports')


@reports_bp.route('/generate/<int:prediction_id>', methods=['POST'])
@jwt_required()
def generate_report(prediction_id):
    user_id = int(get_jwt_identity())
    current_user = User.query.get_or_404(user_id)
    
    pred = Prediction.query.get_or_404(prediction_id)
    if pred.user_id != user_id and current_user.role != 'admin':
        return jsonify({'error': 'Forbidden'}), 403
    
    existing = Report.query.filter_by(prediction_id=prediction_id).first()
    if existing:
        return jsonify({
            'message': 'Report already exists',
            'report': existing.to_dict()
        }), 200
    
    report_folder = current_app.config['REPORT_FOLDER']
    upload_folder = current_app.config['UPLOAD_FOLDER']
    os.makedirs(report_folder, exist_ok=True)
    
    report_filename = generate_pdf_report(pred, current_user, report_folder, upload_folder)
    
    report = Report(
        user_id=user_id,
        prediction_id=prediction_id,
        report_file=report_filename
    )
    db.session.add(report)
    db.session.commit()
    
    return jsonify({
        'message': 'Report generated successfully',
        'report': report.to_dict()
    }), 201


@reports_bp.route('/', methods=['GET'])
@jwt_required()
def list_reports():
    user_id = int(get_jwt_identity())
    current_user = User.query.get_or_404(user_id)
    
    if current_user.role == 'admin':
        rq = Report.query
    else:
        rq = Report.query.filter_by(user_id=user_id)
    
    reports = rq.order_by(Report.created_at.desc()).all()
    return jsonify({'reports': [r.to_dict() for r in reports]}), 200


@reports_bp.route('/download/<int:report_id>', methods=['GET'])
@jwt_required()
def download_report(report_id):
    user_id = int(get_jwt_identity())
    current_user = User.query.get_or_404(user_id)
    
    report = Report.query.get_or_404(report_id)
    if report.user_id != user_id and current_user.role != 'admin':
        return jsonify({'error': 'Forbidden'}), 403
    
    report_folder = current_app.config['REPORT_FOLDER']
    return send_from_directory(
        report_folder,
        report.report_file,
        as_attachment=True,
        download_name=f"radiology_report_{report.id}.pdf"
    )
