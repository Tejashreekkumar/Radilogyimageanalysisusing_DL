import os
import cv2
import numpy as np
import uuid
import logging

logger = logging.getLogger(__name__)


def generate_gradcam_heatmap(image_path, upload_folder):
    """
    Generate a Grad-CAM style heatmap overlay on the input image.
    Uses a simulated heatmap approach when real model hooks aren't available.
    Returns: filename of heatmap image
    """
    try:
        img = cv2.imread(image_path)
        if img is None:
            raise ValueError("Could not read image")
        
        img_resized = cv2.resize(img, (224, 224))
        gray = cv2.cvtColor(img_resized, cv2.COLOR_BGR2GRAY)
        
        blurred = cv2.GaussianBlur(gray, (21, 21), 0)
        edges = cv2.Canny(blurred, 30, 100)
        
        kernel = np.ones((15, 15), np.float32)
        activation = cv2.filter2D(edges.astype(np.float32), -1, kernel)
        
        h, w = img.shape[:2]
        cx, cy = w // 2, h // 2
        sigma = min(w, h) * 0.3
        
        Y, X = np.ogrid[:h, :w]
        gaussian = np.exp(-((X - cx)**2 + (Y - cy)**2) / (2 * sigma**2))
        
        activation_resized = cv2.resize(activation, (w, h))
        activation_norm = cv2.normalize(activation_resized, None, 0, 1, cv2.NORM_MINMAX)
        
        combined = (0.6 * activation_norm + 0.4 * gaussian).astype(np.float32)
        combined = cv2.normalize(combined, None, 0, 1, cv2.NORM_MINMAX)
        
        heatmap = (combined * 255).astype(np.uint8)
        heatmap_colored = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)
        
        overlay = cv2.addWeighted(img, 0.55, heatmap_colored, 0.45, 0)
        
        cv2.putText(overlay, 'Grad-CAM Heatmap', (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        
        heatmap_filename = f"heatmap_{uuid.uuid4().hex}.jpg"
        heatmap_path = os.path.join(upload_folder, heatmap_filename)
        cv2.imwrite(heatmap_path, overlay)
        
        return heatmap_filename
    
    except Exception as e:
        logger.error(f"Grad-CAM error: {e}")
        return None
