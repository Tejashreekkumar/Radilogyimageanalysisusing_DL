import os
import logging

logger = logging.getLogger(__name__)

_models = {}
_model_available = {}

def load_models(app):
    """Load YOLOv8 models at startup. Gracefully handles missing model files."""
    model_paths = app.config.get('MODEL_PATHS', {})
    
    for key, path in model_paths.items():
        if os.path.exists(path):
            try:
                from ultralytics import YOLO
                _models[key] = YOLO(path)
                _model_available[key] = True
                logger.info(f"Loaded model: {key} from {path}")
            except Exception as e:
                logger.error(f"Failed to load model {key}: {e}")
                _models[key] = None
                _model_available[key] = False
        else:
            logger.warning(f"Model file not found: {path} — using demo mode for {key}")
            _models[key] = None
            _model_available[key] = False

def get_model(key):
    return _models.get(key)

def is_model_available(key):
    return _model_available.get(key, False)
