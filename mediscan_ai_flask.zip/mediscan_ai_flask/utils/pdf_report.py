import os
import uuid
from datetime import datetime
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                TableStyle, Image as RLImage, HRFlowable)
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
import logging

logger = logging.getLogger(__name__)


def generate_pdf_report(prediction, user, report_folder, upload_folder):
    """
    Generate a professional PDF report for the given prediction.
    Returns: filename of the generated PDF
    """
    try:
        report_filename = f"report_{uuid.uuid4().hex}.pdf"
        report_path = os.path.join(report_folder, report_filename)
        
        doc = SimpleDocTemplate(
            report_path,
            pagesize=letter,
            rightMargin=0.75 * inch,
            leftMargin=0.75 * inch,
            topMargin=0.75 * inch,
            bottomMargin=0.75 * inch
        )
        
        styles = getSampleStyleSheet()
        
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Title'],
            fontSize=22,
            textColor=colors.HexColor('#1a365d'),
            spaceAfter=6,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        )
        subtitle_style = ParagraphStyle(
            'Subtitle',
            parent=styles['Normal'],
            fontSize=11,
            textColor=colors.HexColor('#4a5568'),
            alignment=TA_CENTER,
            spaceAfter=20
        )
        section_header_style = ParagraphStyle(
            'SectionHeader',
            parent=styles['Heading2'],
            fontSize=13,
            textColor=colors.HexColor('#2d3748'),
            spaceBefore=14,
            spaceAfter=6,
            fontName='Helvetica-Bold',
            borderPad=4
        )
        body_style = ParagraphStyle(
            'Body',
            parent=styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#2d3748'),
            spaceAfter=4,
            leading=16
        )
        result_style = ParagraphStyle(
            'Result',
            parent=styles['Normal'],
            fontSize=13,
            textColor=colors.HexColor('#c53030'),
            fontName='Helvetica-Bold',
            alignment=TA_CENTER,
            spaceAfter=6
        )
        
        story = []
        
        story.append(Paragraph("AI-Powered Radiology Report", title_style))
        story.append(Paragraph("MediScan AI Diagnostic System", subtitle_style))
        story.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor('#2b6cb0')))
        story.append(Spacer(1, 16))
        
        info_data = [
            ['Report ID:', f"RPT-{prediction.id:05d}", 'Date:', datetime.now().strftime('%B %d, %Y')],
            ['Patient Name:', prediction.patient_name or user.full_name, 'Time:', datetime.now().strftime('%H:%M:%S')],
            ['Requesting Physician:', user.full_name, 'Scan Type:', prediction.scan_type],
            ['Patient Email:', user.email, 'Disease Type:', prediction.disease_type or 'N/A'],
        ]
        
        info_table = Table(info_data, colWidths=[1.5*inch, 2.5*inch, 1.2*inch, 2*inch])
        info_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.HexColor('#2b6cb0')),
            ('TEXTCOLOR', (2, 0), (2, -1), colors.HexColor('#2b6cb0')),
            ('ROWBACKGROUNDS', (0, 0), (-1, -1), [colors.HexColor('#ebf8ff'), colors.white]),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#bee3f8')),
            ('PADDING', (0, 0), (-1, -1), 6),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ]))
        story.append(info_table)
        story.append(Spacer(1, 16))
        
        story.append(Paragraph("Diagnostic Results", section_header_style))
        story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#bee3f8')))
        story.append(Spacer(1, 8))
        
        confidence_pct = f"{prediction.confidence:.1f}%" if prediction.confidence else "N/A"
        confidence_val = prediction.confidence or 0
        
        if confidence_val >= 80:
            conf_color = colors.HexColor('#c53030')
        elif confidence_val >= 60:
            conf_color = colors.HexColor('#dd6b20')
        else:
            conf_color = colors.HexColor('#276749')
        
        result_data = [
            ['Finding:', prediction.disease_detected or 'No abnormality detected'],
            ['Confidence Score:', confidence_pct],
            ['Scan Modality:', prediction.scan_type],
            ['Analysis Status:', 'Complete'],
        ]
        
        result_table = Table(result_data, colWidths=[2*inch, 5.25*inch])
        result_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.HexColor('#2b6cb0')),
            ('TEXTCOLOR', (1, 0), (1, 0), colors.HexColor('#c53030')),
            ('FONTNAME', (1, 0), (1, 0), 'Helvetica-Bold'),
            ('ROWBACKGROUNDS', (0, 0), (-1, -1), [colors.HexColor('#fff5f5'), colors.white]),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#fed7d7')),
            ('PADDING', (0, 0), (-1, -1), 8),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ]))
        story.append(result_table)
        story.append(Spacer(1, 16))
        
        img_to_show = None
        for img_attr in ['annotated_image', 'original_image']:
            img_val = getattr(prediction, img_attr, None)
            if img_val:
                candidate = os.path.join(upload_folder, img_val)
                if os.path.exists(candidate):
                    img_to_show = candidate
                    break
        
        if img_to_show:
            story.append(Paragraph("Scan Image with AI Annotations", section_header_style))
            story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#bee3f8')))
            story.append(Spacer(1, 8))
            try:
                rl_img = RLImage(img_to_show, width=4*inch, height=3*inch, kind='proportional')
                story.append(rl_img)
            except Exception as img_err:
                logger.warning(f"Could not embed image: {img_err}")
            story.append(Spacer(1, 12))
        
        disease_info = _get_disease_info(prediction.disease_type, prediction.disease_detected)
        if disease_info:
            story.append(Paragraph("Clinical Information", section_header_style))
            story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#bee3f8')))
            story.append(Spacer(1, 6))
            for line in disease_info:
                story.append(Paragraph(line, body_style))
            story.append(Spacer(1, 12))
        
        story.append(Paragraph("Notes & Recommendations", section_header_style))
        story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#bee3f8')))
        story.append(Spacer(1, 6))
        notes_text = prediction.notes or "Please consult a licensed medical professional for further evaluation and treatment guidance. This AI-generated report is intended as a screening aid only and must not be used as a sole diagnostic tool."
        story.append(Paragraph(notes_text, body_style))
        story.append(Spacer(1, 16))
        
        story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#cbd5e0')))
        story.append(Spacer(1, 6))
        disclaimer = (
            "<b>Disclaimer:</b> This report is generated by an AI-assisted diagnostic system. "
            "It is intended for informational purposes only and is not a substitute for professional medical advice, "
            "diagnosis, or treatment. Always seek the advice of a qualified physician or other qualified health provider "
            "with any questions regarding a medical condition."
        )
        disclaimer_style = ParagraphStyle(
            'Disclaimer', parent=styles['Normal'], fontSize=8,
            textColor=colors.HexColor('#718096'), alignment=TA_CENTER, leading=12
        )
        story.append(Paragraph(disclaimer, disclaimer_style))
        
        doc.build(story)
        return report_filename
    
    except Exception as e:
        logger.error(f"PDF generation error: {e}")
        raise


def _get_disease_info(disease_type, disease_detected):
    disease_type = (disease_type or '').lower()
    disease_detected = (disease_detected or '').lower()
    
    if 'brain' in disease_type or 'tumor' in disease_detected or 'glioma' in disease_detected:
        return [
            "<b>About Brain Tumors:</b> A brain tumor is a mass or growth of abnormal cells in the brain. "
            "Brain tumors can be benign (noncancerous) or malignant (cancerous).",
            "<b>Common Symptoms:</b> Headaches, seizures, vision/hearing problems, memory issues, personality changes.",
            "<b>Recommended Action:</b> Immediate consultation with a neurosurgeon or neuro-oncologist is advised. "
            "Further imaging (MRI with contrast) and biopsy may be required.",
        ]
    elif 'kidney' in disease_type or 'stone' in disease_detected or 'calculi' in disease_detected:
        return [
            "<b>About Kidney Stones:</b> Kidney stones are hard mineral deposits that form inside the kidneys. "
            "They can cause severe pain and urinary complications if left untreated.",
            "<b>Common Symptoms:</b> Severe flank pain, blood in urine, frequent urination, nausea, and vomiting.",
            "<b>Recommended Action:</b> Consult a urologist for further evaluation. "
            "Treatment options include medication, lithotripsy, or surgical removal depending on stone size.",
        ]
    elif 'bone' in disease_type or 'fracture' in disease_detected:
        return [
            "<b>About Bone Fractures:</b> A bone fracture is a break in the continuity of bone tissue. "
            "Fractures can range from hairline cracks to complete breaks.",
            "<b>Common Symptoms:</b> Pain, swelling, bruising, difficulty moving the affected area, visible deformity.",
            "<b>Recommended Action:</b> Consult an orthopedic specialist immediately. "
            "Immobilization, casting, or surgical intervention may be necessary.",
        ]
    return []
