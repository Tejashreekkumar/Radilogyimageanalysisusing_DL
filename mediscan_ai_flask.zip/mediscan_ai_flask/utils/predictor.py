import os
import cv2
import numpy as np
import uuid
import logging
from PIL import Image

logger = logging.getLogger(__name__)

DEMO_RESULTS = {
    'brain': {
        'disease_detected': 'Glioma Tumor',
        'confidence': 0.87,
        'label': 'Brain Tumor'
    },
    'kidney': {
        'disease_detected': 'Kidney Stone (Calculi)',
        'confidence': 0.82,
        'label': 'Kidney Stone'
    },
    'bone': {
        'disease_detected': 'Hairline Fracture',
        'confidence': 0.79,
        'label': 'Bone Fracture'
    }
}

def run_prediction(image_path, model_key, upload_folder, model=None, model_available=False):
    """
    Run YOLOv8 prediction on the given image.
    Falls back to demo mode if model is not available.
    Returns: dict with disease_detected, confidence, annotated_image path
    """
    try:
        if model_available and model is not None:
            return _run_yolo_prediction(image_path, model_key, upload_folder, model)
        else:
            return _run_demo_prediction(image_path, model_key, upload_folder)
    except Exception as e:
        logger.error(f"Prediction error: {e}")
        return _run_demo_prediction(image_path, model_key, upload_folder)


def _run_yolo_prediction(image_path, model_key, upload_folder, model):
    """Run actual YOLOv8 prediction."""
    results = model(image_path, conf=0.25)
    
    annotated_filename = f"annotated_{uuid.uuid4().hex}.jpg"
    annotated_path = os.path.join(upload_folder, annotated_filename)
    
    disease_detected = None
    confidence = None
    
    result = results[0]
    if result.boxes and len(result.boxes) > 0:
        boxes = result.boxes
        best_idx = int(boxes.conf.argmax())
        confidence = float(boxes.conf[best_idx])
        class_id = int(boxes.cls[best_idx])
        
        if result.names:
            disease_detected = result.names.get(class_id, 'Unknown')
        else:
            disease_detected = DEMO_RESULTS.get(model_key, {}).get('disease_detected', 'Detected')
    else:
        disease_detected = 'No abnormality detected'
        confidence = 0.0
    
    annotated_img = result.plot()
    cv2.imwrite(annotated_path, annotated_img)
    
    return {
        'disease_detected': disease_detected,
        'confidence': round(confidence * 100, 2) if confidence else 0.0,
        'annotated_image': annotated_filename
    }


def _run_demo_prediction(image_path, model_key, upload_folder):
    """Demo mode: draw bounding box overlay on original image."""
    demo = DEMO_RESULTS.get(model_key, {
        'disease_detected': 'Anomaly Detected',
        'confidence': 0.75,
        'label': 'Unknown'
    })
    
    try:
        img = cv2.imread(image_path)
        if img is None:
            img = np.zeros((512, 512, 3), dtype=np.uint8)
        
        h, w = img.shape[:2]
        
        x1 = int(w * 0.25)
        y1 = int(h * 0.25)
        x2 = int(w * 0.75)
        y2 = int(h * 0.75)
        
        cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 3)
        
        label = f"{demo['disease_detected']} {demo['confidence']*100:.1f}%"
        font_scale = max(0.5, w / 1000)
        thickness = max(1, int(w / 400))
        
        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, font_scale, thickness)
        cv2.rectangle(img, (x1, y1 - th - 10), (x1 + tw + 10, y1), (0, 255, 0), -1)
        cv2.putText(img, label, (x1 + 5, y1 - 5),
                    cv2.FONT_HERSHEY_SIMPLEX, font_scale, (0, 0, 0), thickness)
        
        annotated_filename = f"annotated_{uuid.uuid4().hex}.jpg"
        annotated_path = os.path.join(upload_folder, annotated_filename)
        cv2.imwrite(annotated_path, img)
        
    except Exception as e:
        logger.error(f"Demo prediction image error: {e}")
        annotated_filename = os.path.basename(image_path)
    
    return {
        'disease_detected': demo['disease_detected'],
        'confidence': round(demo['confidence'] * 100, 2),
        'annotated_image': annotated_filename
    }
